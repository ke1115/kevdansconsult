# HelloWorld (Java) — Starter Android app

What this is
- Minimal native Android app written in Java.
- Two screens: MainActivity (hello + button) and SecondActivity (shows passed name).

Quick setup (beginner-friendly)
1. Install Android Studio (latest stable) from https://developer.android.com/studio
2. Start Android Studio -> New Project -> choose "Empty Activity" -> Language: Java, Minimum SDK: API 21 (or higher).
3. Replace the contents of the generated files with the files provided above (or copy the Java/XML files into the matching paths).
   - Project structure: app/src/main/java/... and app/src/main/res/layout/...
4. Sync project (Android Studio will download Gradle & dependencies).
5. Run:
   - Use an emulator: Tools → AVD Manager → create a virtual device → run.
   - Or use a physical device: enable Developer options → USB debugging, connect via USB (accept prompt on phone).
   - Click the Run ▶ button in Android Studio.

Notes for beginners
- Use Logcat (bottom pane) in Android Studio to view app logs and errors.
- If you see build errors about SDK, install the required SDK platform (prompted by Android Studio).
- Learn the basics: Activity lifecycle (onCreate, onStart, onResume), Intents, layouts (XML), and Views.

Next steps for iOS / cross-platform
- If you want a native iOS app: you'll need to create a separate iOS project in Swift using Xcode. I can provide an equivalent simple Swift starter app.
- If you want one codebase for both platforms: consider Flutter (Dart) or React Native (JS/TS). I can help migrate or create a cross-platform starter.

Tell me what you want next:
- I can prepare a full downloadable Android Studio project ZIP ready to open.
- Or I can also generate a simple Swift/iOS starter to pair with this Android app.
- Or: recommend a cross-platform approach and give a migration plan (Flutter or React Native).
Which would you like me to do next?